/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Vista;

import Controlador.ControladorMaterial;
import Modelo.ClaseMateriales;
import Modelo.ClaseUsuario;
import Modelo.ImagenFondo;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

/**
 *
 * @author chane
 */
public class MenuPrincipal extends javax.swing.JFrame {

    /**
     * Creates new form MenuPrincipal
     */
    ImagenFondo imgFondo;
    ClaseUsuario userSesion;
    private ControladorMaterial controlMat = new ControladorMaterial();

    public MenuPrincipal(ClaseUsuario usuario) {

        imgFondo = new ImagenFondo("src/imagenes/FondoFRM.jpg");
        this.setContentPane(imgFondo);
        initComponents();
        setSize(900, 550);
        setLocationRelativeTo(null);
        setResizable(false);
        configurarBoton(BtnActividades, "Mis actividades", "/Imagenes/user.png");
        configurarBoton(BtnActMat, "Pendientes de entrega", "/Imagenes/user.png");
        configurarBoton(BtnRepAct, "Reportes de actividades", "/Imagenes/user.png");
        configurarBoton(BtnMaterial, "Agregar materiales", "/Imagenes/user.png");
        configurarBoton(BtnRepUsu, "Reportes de usuario", "/Imagenes/user.png");
        configurarBoton(BtnCampañas, "Agregar usuarios", "/Imagenes/user.png");
        configurarBoton(BtnRepGen, "Reportes", "/Imagenes/user.png");
        configurarBoton(BtnGenAct, "Generar actividades", "/Imagenes/user.png");
        configurarBoton(BtnUsuarios, "Agregar usuario", "/Imagenes/user.png");
        configurarBoton(BtnCampañas, "Campañas", "/Imagenes/user.png");
        configurarBoton(BtnUbicaciones, "Ubicaciones", "/Imagenes/user.png");
        userSesion = usuario;
        configurarInterfazPorRol();
    }

    private void configurarInterfazPorRol() {
        if (userSesion == null) {
            return;
        }
        lblNombreUsuario.setText("Bienvenido: " + userSesion.getNombre() + " " + userSesion.getApellido() + "  Rol: " + userSesion.getRol());
        String rol = userSesion.getRol();

        if (rol.equals("ALMACENISTA")) {
            verificarAlertasStock();
        }

        switch (rol) {
            case "ADMINISTRADOR":
                BtnActividades.setEnabled(false);
                BtnRepAct.setEnabled(false);
                BtnMaterial.setEnabled(false);
                BtnActMat.setEnabled(false);
                BtnGenAct.setEnabled(false);
                BtnRepGen.setEnabled(false);
                BtnUbicaciones.setEnabled(false);
                BtnCampañas.setEnabled(false);
                break;

            case "SUPERVISOR":
                break;

            case "ALMACENISTA":
                BtnGenAct.setEnabled(false);
                BtnRepGen.setEnabled(false);
                BtnCampañas.setEnabled(false);
                BtnRepUsu.setEnabled(false);
                BtnActividades.setEnabled(false);
                BtnRepAct.setEnabled(false);
                BtnUsuarios.setEnabled(false);
                BtnUbicaciones.setEnabled(false);
                break;

            case "ASOCIADO":
                BtnMaterial.setEnabled(false);
                BtnActMat.setEnabled(false);
                BtnGenAct.setEnabled(false);
                BtnRepGen.setEnabled(false);
                BtnCampañas.setEnabled(false);
                BtnRepUsu.setEnabled(false);
                BtnUsuarios.setEnabled(false);
                BtnUbicaciones.setEnabled(false);
                break;
        }
    }

    private void verificarAlertasStock() {
        ClaseMateriales[] bajos = controlMat.consultarStockBajo();

        if (bajos != null && bajos.length > 0) {
            StringBuilder mensaje = new StringBuilder();
            mensaje.append("<html><body style='width: 250px;'>");
            mensaje.append("<h2 style='color:red;'>⚠️ ALERTA DE STOCK BAJO</h2>");
            mensaje.append("<p>Los siguientes materiales están por debajo del mínimo:</p><ul>");

            for (ClaseMateriales m : bajos) {
                mensaje.append("<li><b>").append(m.getNombreMaterial()).append("</b>")
                        .append("<br>Disponible: <span style='color:red;'>").append(m.getCantidadDisponible()).append("</span>")
                        .append(" (Mín: ").append(m.getStockMinimo()).append(")</li><br>");
            }

            mensaje.append("</ul></body></html>");

            JOptionPane.showMessageDialog(this, mensaje.toString(), "Sistema de Almacén IMU", JOptionPane.WARNING_MESSAGE);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BtnActividades = new javax.swing.JButton();
        lblNombreUsuario = new javax.swing.JLabel();
        BtnRepAct = new javax.swing.JButton();
        BtnActMat = new javax.swing.JButton();
        BtnMaterial = new javax.swing.JButton();
        BtnRepUsu = new javax.swing.JButton();
        BtnRepGen = new javax.swing.JButton();
        BtnGenAct = new javax.swing.JButton();
        BtnCampañas = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        BtnUsuarios = new javax.swing.JButton();
        BtnUbicaciones = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));

        BtnActividades.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/MisAct.png"))); // NOI18N
        BtnActividades.setText("Mis Actividades");
        BtnActividades.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(86, 191, 22), 4));
        BtnActividades.setBorderPainted(false);
        BtnActividades.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnActividades.setFocusPainted(false);
        BtnActividades.setOpaque(true);
        BtnActividades.setPreferredSize(new java.awt.Dimension(180, 60));
        BtnActividades.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BtnActividadesMouseEntered(evt);
            }
        });
        BtnActividades.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnActividadesActionPerformed(evt);
            }
        });

        lblNombreUsuario.setForeground(new java.awt.Color(255, 255, 255));
        lblNombreUsuario.setText("Bienvenido:    ");

        BtnRepAct.setText("Rep Actividades");
        BtnRepAct.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(86, 191, 22), 4));
        BtnRepAct.setBorderPainted(false);
        BtnRepAct.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnRepAct.setFocusPainted(false);
        BtnRepAct.setOpaque(true);
        BtnRepAct.setPreferredSize(new java.awt.Dimension(180, 60));
        BtnRepAct.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BtnRepActMouseEntered(evt);
            }
        });
        BtnRepAct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnRepActActionPerformed(evt);
            }
        });

        BtnActMat.setText("Entrega Material");
        BtnActMat.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(86, 191, 22), 4));
        BtnActMat.setBorderPainted(false);
        BtnActMat.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnActMat.setFocusPainted(false);
        BtnActMat.setOpaque(true);
        BtnActMat.setPreferredSize(new java.awt.Dimension(180, 60));
        BtnActMat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BtnActMatMouseEntered(evt);
            }
        });
        BtnActMat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnActMatActionPerformed(evt);
            }
        });

        BtnMaterial.setText("Material");
        BtnMaterial.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(86, 191, 22), 4));
        BtnMaterial.setBorderPainted(false);
        BtnMaterial.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnMaterial.setFocusPainted(false);
        BtnMaterial.setOpaque(true);
        BtnMaterial.setPreferredSize(new java.awt.Dimension(180, 60));
        BtnMaterial.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BtnMaterialMouseEntered(evt);
            }
        });
        BtnMaterial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnMaterialActionPerformed(evt);
            }
        });

        BtnRepUsu.setText("Reporte Usuarios");
        BtnRepUsu.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(86, 191, 22), 4));
        BtnRepUsu.setBorderPainted(false);
        BtnRepUsu.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnRepUsu.setFocusPainted(false);
        BtnRepUsu.setOpaque(true);
        BtnRepUsu.setPreferredSize(new java.awt.Dimension(180, 60));
        BtnRepUsu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BtnRepUsuMouseEntered(evt);
            }
        });
        BtnRepUsu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnRepUsuActionPerformed(evt);
            }
        });

        BtnRepGen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/user.png"))); // NOI18N
        BtnRepGen.setText("Reporte General");
        BtnRepGen.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(86, 191, 22), 4));
        BtnRepGen.setBorderPainted(false);
        BtnRepGen.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnRepGen.setFocusPainted(false);
        BtnRepGen.setOpaque(true);
        BtnRepGen.setPreferredSize(new java.awt.Dimension(180, 60));
        BtnRepGen.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BtnRepGenMouseEntered(evt);
            }
        });
        BtnRepGen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnRepGenActionPerformed(evt);
            }
        });

        BtnGenAct.setText("Generar actividad");
        BtnGenAct.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(86, 191, 22), 4));
        BtnGenAct.setBorderPainted(false);
        BtnGenAct.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnGenAct.setFocusPainted(false);
        BtnGenAct.setOpaque(true);
        BtnGenAct.setPreferredSize(new java.awt.Dimension(180, 60));
        BtnGenAct.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BtnGenActMouseEntered(evt);
            }
        });
        BtnGenAct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnGenActActionPerformed(evt);
            }
        });

        BtnCampañas.setText("Campañas");
        BtnCampañas.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(86, 191, 22), 4));
        BtnCampañas.setBorderPainted(false);
        BtnCampañas.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnCampañas.setFocusPainted(false);
        BtnCampañas.setOpaque(true);
        BtnCampañas.setPreferredSize(new java.awt.Dimension(180, 60));
        BtnCampañas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BtnCampañasMouseEntered(evt);
            }
        });
        BtnCampañas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnCampañasActionPerformed(evt);
            }
        });

        jButton1.setText("Cerrar sesión");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        BtnUsuarios.setText("Generar usuarios");
        BtnUsuarios.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(86, 191, 22), 4));
        BtnUsuarios.setBorderPainted(false);
        BtnUsuarios.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnUsuarios.setFocusPainted(false);
        BtnUsuarios.setOpaque(true);
        BtnUsuarios.setPreferredSize(new java.awt.Dimension(180, 60));
        BtnUsuarios.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BtnUsuariosMouseEntered(evt);
            }
        });
        BtnUsuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnUsuariosActionPerformed(evt);
            }
        });

        BtnUbicaciones.setText("Ubicaciones");
        BtnUbicaciones.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(86, 191, 22), 4));
        BtnUbicaciones.setBorderPainted(false);
        BtnUbicaciones.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnUbicaciones.setFocusPainted(false);
        BtnUbicaciones.setOpaque(true);
        BtnUbicaciones.setPreferredSize(new java.awt.Dimension(180, 60));
        BtnUbicaciones.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BtnUbicacionesMouseEntered(evt);
            }
        });
        BtnUbicaciones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnUbicacionesActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(198, 198, 198)
                        .addComponent(lblNombreUsuario))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(BtnRepAct, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(BtnActividades, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton1))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(BtnMaterial, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(BtnActMat, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(BtnGenAct, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(BtnRepGen, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(BtnCampañas, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(BtnUsuarios, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(BtnUbicaciones, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(BtnRepUsu, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(58, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(lblNombreUsuario)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 170, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BtnMaterial, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BtnGenAct, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BtnActividades, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BtnCampañas, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BtnUsuarios, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(82, 82, 82)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BtnActMat, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BtnRepAct, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BtnUbicaciones, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BtnRepGen, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BtnRepUsu, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(48, 48, 48)
                .addComponent(jButton1)
                .addGap(36, 36, 36))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void BtnActividadesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnActividadesActionPerformed
        //jButton1.addMouseListener(new java.awt.event.MouseAdapter() {

        //public void mouseEntered(java.awt.event.MouseEvent evt) {
        //  jButton1.setBackground(Color.decode("#21618C"));
        //}
        //public void mouseExited(java.awt.event.MouseEvent evt) {
        //  jButton1.setBackground(Color.decode("#3498DB"));
        //}
//});
    }//GEN-LAST:event_BtnActividadesActionPerformed

    private void BtnActividadesMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnActividadesMouseEntered
        // TODO add your handling code here:
        BtnActividades.setContentAreaFilled(true);
    }//GEN-LAST:event_BtnActividadesMouseEntered

    private void BtnRepActMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnRepActMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnRepActMouseEntered

    private void BtnRepActActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnRepActActionPerformed
        // TODO add your handling code here:
        ReporteActividades rep = new ReporteActividades(userSesion);
        rep.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_BtnRepActActionPerformed

    private void BtnActMatMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnActMatMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnActMatMouseEntered

    private void BtnActMatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnActMatActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnActMatActionPerformed

    private void BtnMaterialMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnMaterialMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnMaterialMouseEntered

    private void BtnMaterialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnMaterialActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnMaterialActionPerformed

    private void BtnRepUsuMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnRepUsuMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnRepUsuMouseEntered

    private void BtnRepUsuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnRepUsuActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnRepUsuActionPerformed

    private void BtnRepGenMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnRepGenMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnRepGenMouseEntered

    private void BtnRepGenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnRepGenActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnRepGenActionPerformed

    private void BtnGenActMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnGenActMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnGenActMouseEntered

    private void BtnGenActActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnGenActActionPerformed
        // TODO add your handling code here: 
        GenerarActividades frmGen = new GenerarActividades(this.userSesion);
        frmGen.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_BtnGenActActionPerformed

    private void BtnCampañasMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnCampañasMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnCampañasMouseEntered

    private void BtnCampañasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnCampañasActionPerformed
        // TODO add your handling code here:
        Campañas cam = new Campañas(userSesion);
        cam.setVisible(true);
        this.dispose();
       
    }//GEN-LAST:event_BtnCampañasActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        Login lo = new Login();
        lo.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void BtnUsuariosMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnUsuariosMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnUsuariosMouseEntered

    private void BtnUsuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnUsuariosActionPerformed
        // TODO add your handling code here:
         Usuarios usu = new Usuarios(this.userSesion);
        usu.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_BtnUsuariosActionPerformed

    private void BtnUbicacionesMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnUbicacionesMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnUbicacionesMouseEntered

    private void BtnUbicacionesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnUbicacionesActionPerformed
        // TODO add your handling code here:
        Ubicaciones ubi = new Ubicaciones(userSesion);
        ubi.setVisible(true);
        this.dispose();
        
    }//GEN-LAST:event_BtnUbicacionesActionPerformed

    private void configurarBoton(JButton boton, String texto, String icono) {
        boton.setText(texto);
        boton.setIcon(new ImageIcon(getClass().getResource(icono)));
        boton.setHorizontalTextPosition(SwingConstants.CENTER);
        boton.setVerticalTextPosition(SwingConstants.BOTTOM);
        boton.setIconTextGap(10);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuPrincipal(null).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnActMat;
    private javax.swing.JButton BtnActividades;
    private javax.swing.JButton BtnCampañas;
    private javax.swing.JButton BtnGenAct;
    private javax.swing.JButton BtnMaterial;
    private javax.swing.JButton BtnRepAct;
    private javax.swing.JButton BtnRepGen;
    private javax.swing.JButton BtnRepUsu;
    private javax.swing.JButton BtnUbicaciones;
    private javax.swing.JButton BtnUsuarios;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel lblNombreUsuario;
    // End of variables declaration//GEN-END:variables
}
