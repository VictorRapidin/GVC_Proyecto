/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Vista;

import Controlador.ControladorActividad;
import Modelo.ClaseUsuario;
import Modelo.ImagenFondo;

/**
 *
 * @author ghust
 */
public class ReporteActividades extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(ReporteActividades.class.getName());

    /**
     * Creates new form ReporteActividades
     */
    ClaseUsuario userSesion;
    ImagenFondo imgFondo;

    public ReporteActividades(ClaseUsuario usuario) {
        this.userSesion = userSesion;
        imgFondo = new ImagenFondo("src/imagenes/FondoFRM.jpg");
        this.setContentPane(imgFondo);
        initComponents();
        cargarTabla();
        setSize(900, 550);
        setLocationRelativeTo(null);
        setResizable(false);
        userSesion = usuario;
        lblNombreUsuario.setText("Bienvenido: " + userSesion.getNombre() + " " + userSesion.getApellido() + "  Rol: " + userSesion.getRol());
    }

    
    ReporteActividades(ClaseUsuario userSesion, ControladorActividad ctrlAct) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private String obtenerNombreUsuario(int idBusqueda, Modelo.ClaseUsuario[] listaUsuarios) {
        if (idBusqueda == 0 || listaUsuarios == null) {
            return "Ninguno";
        }
        for (Modelo.ClaseUsuario u : listaUsuarios) {
            if (u.getIdUsuario() == idBusqueda) {
                return u.getNombre();
            }
        }
        return "Desconocido";
    }

    private String obtenerNombreCampania(int idBusqueda, Modelo.ClaseCampania[] listaCampanias) {
        if (idBusqueda == 0 || listaCampanias == null) {
            return "Sin Campaña";
        }
        for (Modelo.ClaseCampania c : listaCampanias) {
            if (c.getIdCampania() == idBusqueda) {
                return c.getNombre();
            }
        }
        return "Desconocida";
    }

    private String obtenerNombreUbicacion(int idBusqueda, Modelo.ClaseUbicaciones[] listaUbicaciones) {
        if (idBusqueda == 0 || listaUbicaciones == null) {
            return "Sin Ubicación";
        }
        for (Modelo.ClaseUbicaciones u : listaUbicaciones) {
            if (u.getIdUbicacion() == idBusqueda) {
                String c1 = (u.getCalle1() != null) ? u.getCalle1() : "S/C";
                String c2 = (u.getCalle2() != null && !u.getCalle2().isEmpty()) ? " y " + u.getCalle2() : "";
                return c1 + c2;
            }
        }
        return "Desconocida";
    }

    private void cargarTabla() {
        javax.swing.table.DefaultTableModel modelo = new javax.swing.table.DefaultTableModel();
        modelo.addColumn("Actividad");
        modelo.addColumn("Campaña");
        modelo.addColumn("Ubicación");
        modelo.addColumn("Asignado(s)"); 
        modelo.addColumn("Fecha Prog.");
        modelo.addColumn("Estado");
        modelo.addColumn("Prioridad");

        Controlador.ControladorActividad controlAct = new Controlador.ControladorActividad();
        Modelo.ClaseActividad[] actividades = controlAct.leerActividades();

        Controlador.ControladorUsuario controlUsu = new Controlador.ControladorUsuario();
        Modelo.ClaseUsuario[] usuarios = controlUsu.leerUsuarios();

        Controlador.ControladorCampanias controlCamp = new Controlador.ControladorCampanias();
        Modelo.ClaseCampania[] campanias = controlCamp.leerCampanias();

        Controlador.ControladorUbicaciones controlUbi = new Controlador.ControladorUbicaciones();
        Modelo.ClaseUbicaciones[] ubicaciones = controlUbi.leerUbicaciones();
        if (actividades != null) {
            for (Modelo.ClaseActividad act : actividades) {
                if (act != null) {
                    Object[] fila = new Object[7];

                    
                    fila[0] = act.getNombreActividad();
                    fila[1] = obtenerNombreCampania(act.getIdCampania(), campanias);
                    fila[2] = obtenerNombreUbicacion(act.getIdUbicacion(), ubicaciones);
                    String asig1 = obtenerNombreUsuario(act.getIdAsignado(), usuarios);
                    String asig2 = obtenerNombreUsuario(act.getIdAsignado(), usuarios);
                    fila[3] = asig2.equals("Ninguno") ? asig1 : asig1 + " / " + asig2;

                    fila[4] = act.getFechaProgramada();
                    fila[5] = act.getEstado();
                    fila[6] = act.getPrioridad();

                    modelo.addRow(fila);
                }
            }
        }

        
        tblActividades.setModel(modelo);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tblActividades = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jbnIncidencias = new javax.swing.JButton();
        jbnVolver = new javax.swing.JButton();
        lblNombreUsuario = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        tblActividades.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(41, 112, 172), null));
        tblActividades.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Usuario", "Actividad", "Ubicacion", "Estado"
            }
        ));
        jScrollPane1.setViewportView(tblActividades);

        jLabel1.setFont(new java.awt.Font("Open Sans", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(68, 138, 25));
        jLabel1.setText("REPORTE DE ACTIVIDADES");

        jbnIncidencias.setText("Nueva Incidencia");

        jbnVolver.setText("Volver");
        jbnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbnVolverActionPerformed(evt);
            }
        });

        lblNombreUsuario.setForeground(new java.awt.Color(255, 255, 255));
        lblNombreUsuario.setText("jLabel2");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(183, 183, 183)
                        .addComponent(jbnIncidencias)
                        .addGap(65, 65, 65)
                        .addComponent(jbnVolver))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(134, 134, 134)
                        .addComponent(lblNombreUsuario))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(177, 177, 177)
                        .addComponent(jLabel1)))
                .addContainerGap(261, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(lblNombreUsuario)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 117, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbnIncidencias)
                    .addComponent(jbnVolver))
                .addGap(31, 31, 31))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jbnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbnVolverActionPerformed
        // TODO add your handling code here:
        MenuPrincipal menu = new MenuPrincipal(this.userSesion);
        menu.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jbnVolverActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new ReporteActividades(null).setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton jbnIncidencias;
    private javax.swing.JButton jbnVolver;
    private javax.swing.JLabel lblNombreUsuario;
    private javax.swing.JTable tblActividades;
    // End of variables declaration//GEN-END:variables
}
