/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import Modelo.ClaseMateriales;
import Modelo.ConexionBD;

/**
 *
 * @author porqu
 */
public class ControladorMaterial {

    private ConexionBD conexion = new ConexionBD();
    private int cantRegistros;

    public ControladorMaterial() {
        conexion = new ConexionBD();
        this.cantRegistros = 0;
    }

    private static final String INSERT_MATERIAL
            = "INSERT INTO material(NOMBRE_MATERIAL, TIPO, CANTIDAD_DISPONIBLE, STOCK_MINIMO, ACTIVO) VALUES (?, ?, ?, ?, 1)";

    private static final String SELECT_ALL_MATERIALES
            = "SELECT * FROM material WHERE ACTIVO = 1";

    private static final String SELECT_COUNT_MATERIALES
            = "SELECT COUNT(*) AS CANT FROM material WHERE ACTIVO = 1";

    private static final String UPDATE_MATERIAL
            = "UPDATE material SET NOMBRE_MATERIAL=?, TIPO=?, CANTIDAD_DISPONIBLE=?, STOCK_MINIMO=? WHERE ID_MATERIAL=?";

    private static final String DELETE_LOGICO_MATERIAL
            = "UPDATE material SET ACTIVO = 0 WHERE ID_MATERIAL=?";

    private static final String SELECT_MATERIAL_BY_ID
            = "SELECT * FROM material WHERE ID_MATERIAL=?";

    private static final String SELECT_LOW_STOCK
            = "SELECT * FROM material WHERE CANTIDAD_DISPONIBLE <= STOCK_MINIMO AND ACTIVO = 1";

    public int getCantRegistros() {
        return cantRegistros;
    }

    public void setCantRegistros(int cantRegistros) {
        this.cantRegistros = cantRegistros;
    }

    public boolean registrarMaterial(ClaseMateriales material) {
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = conexion.getConnection();
            ps = conn.prepareStatement(INSERT_MATERIAL);
            ps.setString(1, material.getNombreMaterial());
            ps.setString(2, material.getTipo());
            ps.setInt(3, material.getCantidadDisponible());
            ps.setInt(4, material.getStockMinimo());
            return ps.executeUpdate() > 0;
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al registrar Material: " + e.getMessage(), "Aviso", JOptionPane.ERROR_MESSAGE);
            return false;
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conexion.closeConnection(conn);
                }
            } catch (SQLException ex) {
            }
        }
    }

    public ClaseMateriales[] leerMateriales() {
        ClaseMateriales[] aMateriales = null;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        cantRegistros = 0;
        try {
            conn = conexion.getConnection();
            ps = conn.prepareStatement(SELECT_COUNT_MATERIALES);
            rs = ps.executeQuery();
            if (rs.next()) {
                cantRegistros = rs.getInt("CANT");
            }
            rs.close();
            ps.close();
            aMateriales = new ClaseMateriales[cantRegistros];
            ps = conn.prepareStatement(SELECT_ALL_MATERIALES);
            rs = ps.executeQuery();
            int i = 0;
            while (rs.next()) {
                ClaseMateriales mat = new ClaseMateriales();
                mat.setIdMaterial(rs.getInt("ID_MATERIAL"));
                mat.setNombreMaterial(rs.getString("NOMBRE_MATERIAL"));
                mat.setTipo(rs.getString("TIPO"));
                mat.setCantidadDisponible(rs.getInt("CANTIDAD_DISPONIBLE"));
                mat.setStockMinimo(rs.getInt("STOCK_MINIMO"));
                aMateriales[i] = mat;
                i++;
            }
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al leer materiales: " + e.getMessage(), "Aviso", JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conexion.closeConnection(conn);
                }
            } catch (SQLException ex) {
            }
        }
        return aMateriales;
    }

    public boolean actualizarMaterial(ClaseMateriales material) {
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = conexion.getConnection();
            ps = conn.prepareStatement(UPDATE_MATERIAL);
            ps.setString(1, material.getNombreMaterial());
            ps.setString(2, material.getTipo());
            ps.setInt(3, material.getCantidadDisponible());
            ps.setInt(4, material.getStockMinimo());
            ps.setInt(5, material.getIdMaterial());
            return ps.executeUpdate() > 0;
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al actualizar material: " + e.getMessage(), "Aviso", JOptionPane.ERROR_MESSAGE);
            return false;
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conexion.closeConnection(conn);
                }
            } catch (SQLException e) {
            }
        }
    }

    public boolean eliminarMaterial(int idMaterial) {
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = conexion.getConnection();
            ps = conn.prepareStatement(DELETE_LOGICO_MATERIAL);
            ps.setInt(1, idMaterial);
            return ps.executeUpdate() > 0;
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar material: " + e.getMessage(), "Aviso", JOptionPane.ERROR_MESSAGE);
            return false;
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conexion.closeConnection(conn);
                }
            } catch (SQLException ex) {
            }
        }
    }

    public ClaseMateriales buscarMaterial(int idMaterial) {
        ClaseMateriales mat = null;
        try (Connection conn = conexion.getConnection(); PreparedStatement ps = conn.prepareStatement(SELECT_MATERIAL_BY_ID)) {
            ps.setInt(1, idMaterial);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    mat = new ClaseMateriales();
                    mat.setIdMaterial(rs.getInt("ID_MATERIAL"));
                    mat.setNombreMaterial(rs.getString("NOMBRE_MATERIAL"));
                    mat.setTipo(rs.getString("TIPO"));
                    mat.setCantidadDisponible(rs.getInt("CANTIDAD_DISPONIBLE"));
                    mat.setStockMinimo(rs.getInt("STOCK_MINIMO"));
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al buscar material: " + e.getMessage(), "Aviso", JOptionPane.ERROR_MESSAGE);
        }
        return mat;
    }

    public ClaseMateriales[] consultarStockBajo() {
        ClaseMateriales[] materialesCriticos = null;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int contador = 0;
        try {
            conn = conexion.getConnection();
            ps = conn.prepareStatement("SELECT COUNT(*) AS CANT FROM material WHERE CANTIDAD_DISPONIBLE <= STOCK_MINIMO AND ACTIVO = 1");
            rs = ps.executeQuery();
            if (rs.next()) {
                contador = rs.getInt("CANT");
            }
            materialesCriticos = new ClaseMateriales[contador];
            ps = conn.prepareStatement(SELECT_LOW_STOCK);
            rs = ps.executeQuery();
            int i = 0;
            while (rs.next()) {
                ClaseMateriales mat = new ClaseMateriales();
                mat.setNombreMaterial(rs.getString("NOMBRE_MATERIAL"));
                mat.setCantidadDisponible(rs.getInt("CANTIDAD_DISPONIBLE"));
                mat.setStockMinimo(rs.getInt("STOCK_MINIMO"));
                materialesCriticos[i] = mat;
                i++;
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("Error en alerta de stock: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conexion.closeConnection(conn);
                }
            } catch (SQLException ex) {
            }
        }
        return materialesCriticos;
    }

    public boolean descontarStockConfirmado(int idMaterial, int cantidad) {
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = conexion.getConnection();
            String sql = "UPDATE material SET CANTIDAD_DISPONIBLE = CANTIDAD_DISPONIBLE - ? WHERE ID_MATERIAL = ?";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, cantidad);
            ps.setInt(2, idMaterial);
            return ps.executeUpdate() > 0;
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al descontar stock: " + e.getMessage());
            return false;
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conexion.closeConnection(conn);
                }
            } catch (SQLException ex) {
            }
        }
    }
}
