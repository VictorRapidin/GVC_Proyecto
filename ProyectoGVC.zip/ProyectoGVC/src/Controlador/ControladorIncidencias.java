/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author porqu
 */
public class ControladorIncidencias {

    private ConexionBD conexion = new ConexionBD();

    public ControladorIncidencias() {
        conexion = new ConexionBD();
    }

    /**
     * REGISTRAR: Crea un nuevo reporte de incidencia ligado a una actividad
     */
    public boolean registrarIncidencia(int idAct, String tipo, String desc) {
        java.sql.Connection conn = null;
        java.sql.PreparedStatement ps = null;

        String sql = "INSERT INTO incidencias (TIPO, DESCRIPCION, ID_ACTIVIDAD, ESTADO) VALUES (?, ?, ?, 'PENDIENTE')";

        try {
            conn = conexion.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, tipo);
            ps.setString(2, desc);
            ps.setInt(3, idAct);

            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("Error al registrar: " + e.getMessage());
            return false;
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conexion.closeConnection(conn);
                }
            } catch (Exception ex) {
            }
        }
    }

    /**
     * LEER: Obtiene la lista general para la tabla de Reporte de Incidencias
     */
    public Object[][] leerTodasLasIncidencias() {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Object[][] datos = null;

        String sql = "SELECT i.ID_INCIDENCIA, i.TIPO_INCIDENCIA, u.CODIGO, i.FECHA_REPORTE, i.ESTADO "
                + "FROM incidencias i "
                + "INNER JOIN ubicaciones u ON i.ID_UBICACION = u.ID_UBICACION "
                + "ORDER BY i.FECHA_REPORTE DESC";

        try {
            conn = conexion.getConnection();
            ps = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            rs = ps.executeQuery();

            rs.last();
            int filas = rs.getRow();
            rs.beforeFirst();

            datos = new Object[filas][5];
            int i = 0;
            while (rs.next()) {
                datos[i][0] = rs.getInt("ID_INCIDENCIA");
                datos[i][1] = rs.getString("TIPO_INCIDENCIA");
                datos[i][2] = rs.getString("CODIGO");
                datos[i][3] = rs.getDate("FECHA_REPORTE");
                datos[i][4] = rs.getString("ESTADO");
                i++;
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("Error al leer incidencias: " + e.getMessage());
        } finally {
            cerrarRecursos(rs, ps, conn);
        }
        return datos;
    }

    /**
     * DETALLE: Trae la descripción y el nombre del usuario que reportó
     */
    public Object[] obtenerDetalleIncidencia(int idIncidencia) {
        Object[] detalle = new Object[2];
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        String sql = "SELECT i.DESCRIPCION, us.NOMBRE "
                + "FROM incidencias i "
                + "INNER JOIN usuarios us ON i.ID_USUARIO = us.ID_USUARIO "
                + "WHERE i.ID_INCIDENCIA = ?";

        try {
            conn = conexion.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, idIncidencia);
            rs = ps.executeQuery();

            if (rs.next()) {
                detalle[0] = rs.getString("DESCRIPCION");
                detalle[1] = rs.getString("NOMBRE");
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("Error al obtener detalle: " + e.getMessage());
        } finally {
            cerrarRecursos(rs, ps, conn);
        }
        return detalle;
    }

    /**
     * ACTUALIZAR: Para que el supervisor cambie el estado (ej. de ABIERTA a
     * SOLUCIONADA)
     */
    public boolean actualizarEstadoIncidencia(int idIncidencia, String nuevoEstado) {
        Connection conn = null;
        PreparedStatement ps = null;
        String sql = "UPDATE incidencias SET ESTADO = ? WHERE ID_INCIDENCIA = ?";

        try {
            conn = conexion.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, nuevoEstado);
            ps.setInt(2, idIncidencia);

            return ps.executeUpdate() > 0;
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("Error al actualizar incidencia: " + e.getMessage());
            return false;
        } finally {
            cerrarRecursos(null, ps, conn);
        }
    }

    private void cerrarRecursos(ResultSet rs, PreparedStatement ps, Connection conn) {
        try {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conexion.closeConnection(conn);
            }
        } catch (SQLException ex) {
            System.err.println("Error al cerrar recursos: " + ex.getMessage());
        }
    }
}
