/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.ClaseCampania;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import Modelo.ConexionBD;

/**
 *
 * @author porqu
 */
public class ControladorCampanias {

    private ConexionBD conexion = new ConexionBD();
    private int cantRegistros;

    public ControladorCampanias() {
        conexion = new ConexionBD();
        this.cantRegistros = 0;
    }

    private static final String INSERT_CAMPANIA
            = "INSERT INTO campanias(NOMBRE, DESCRIPCION, FECHA_INICIO, FECHA_FIN, ESTADO) VALUES (?, ?, ?, ?, ?)";

    private static final String SELECT_ALL_CAMPANIAS
            = "SELECT * FROM campanias";

    public boolean registrarCampania(ClaseCampania c) {
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = conexion.getConnection();
            ps = conn.prepareStatement(INSERT_CAMPANIA);
            ps.setString(1, c.getNombre());
            ps.setString(2, c.getDescripcion());
            ps.setString(3, c.getFechaInicio());
            ps.setString(4, c.getFechaFin());
            ps.setString(5, c.getEstado());
            return ps.executeUpdate() > 0;
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al registrar: " + e.getMessage());
            return false;
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conexion.closeConnection(conn);
                }
            } catch (SQLException ex) {
            }
        }
    }

    public ClaseCampania[] leerCampanias() {
        ClaseCampania[] aCampanias = null;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = conexion.getConnection();
            ps = conn.prepareStatement("SELECT COUNT(*) AS CANT FROM campanias");
            rs = ps.executeQuery();
            if (rs.next()) {
                cantRegistros = rs.getInt("CANT");
            }

            aCampanias = new ClaseCampania[cantRegistros];
            ps = conn.prepareStatement(SELECT_ALL_CAMPANIAS);
            rs = ps.executeQuery();
            int i = 0;
            while (rs.next()) {
                ClaseCampania c = new ClaseCampania();
                c.setIdCampania(rs.getInt("ID_CAMPANIA"));
                c.setNombre(rs.getString("NOMBRE"));
                c.setDescripcion(rs.getString("DESCRIPCION"));
                c.setFechaInicio(rs.getString("FECHA_INICIO"));
                c.setFechaFin(rs.getString("FECHA_FIN"));
                c.setEstado(rs.getString("ESTADO"));
                aCampanias[i] = c;
                i++;
            }
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al leer: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conexion.closeConnection(conn);
                }
            } catch (SQLException ex) {
            }
        }
        return aCampanias;
    }
}
