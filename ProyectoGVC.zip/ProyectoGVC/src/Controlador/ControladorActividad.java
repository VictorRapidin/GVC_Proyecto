/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import Modelo.ClaseActividad;
import Modelo.ConexionBD;

/**
 *
 * @author porqu
 */
public class ControladorActividad {

    private ConexionBD conexion = new ConexionBD();
    private int cantRegistros;

    public ControladorActividad() {
        conexion = new ConexionBD();
        this.cantRegistros = 0;
    }

    private static final String INSERT_ACTIVIDAD
            = "INSERT INTO actividades(NOMBRE_ACTIVIDAD, DESCRIPCION, FECHA_CREACION, FECHA_PROGRAMADA, FECHA_INICIO, FECHA_FINALIZACION, ESTADO, PRIORIDAD, ID_CREADOR, ID_ASIGNADO, ID_ASIGNADO_2, ID_UBICACION, ID_CAMPANIA) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String INSERT_ACTIVIDAD_MATERIAL
            = "INSERT INTO actividad_material(ID_ACTIVIDAD, ID_MATERIAL, CANTIDAD_USADA, ENTREGADO) VALUES (?, ?, ?, 0)";

    private static final String SELECT_ALL_ACTIVIDADES
            = "SELECT * FROM actividades";

    private static final String SELECT_COUNT_ACTIVIDADES
            = "SELECT COUNT(*) AS CANT FROM actividades";

    private static final String UPDATE_ACTIVIDAD
            = "UPDATE actividades SET NOMBRE_ACTIVIDAD=?, DESCRIPCION=?, FECHA_PROGRAMADA=?, FECHA_INICIO=?, FECHA_FINALIZACION=?, ESTADO=?, PRIORIDAD=?, ID_ASIGNADO=?, ID_ASIGNADO_2=?, ID_UBICACION=?, ID_CAMPANIA=? WHERE ID_ACTIVIDAD=?";

    private static final String DELETE_ACTIVIDAD
            = "DELETE FROM actividades WHERE ID_ACTIVIDAD=?";

    private static final String SELECT_ACTIVIDAD_BY_ID
            = "SELECT * FROM actividades WHERE ID_ACTIVIDAD=?";

    public int getCantRegistros() {
        return cantRegistros;
    }

    public void setCantRegistros(int cantRegistros) {
        this.cantRegistros = cantRegistros;
    }

   public boolean registrarActividadCompleta(ClaseActividad actividad, int idMaterial, int cantidadMaterial) {
    Connection conn = null;
    PreparedStatement psAct = null;
    PreparedStatement psMat = null;
    ResultSet rs = null;

    try {
        conn = conexion.getConnection();
        conn.setAutoCommit(false);

        psAct = conn.prepareStatement(INSERT_ACTIVIDAD, PreparedStatement.RETURN_GENERATED_KEYS);
        psAct.setString(1, actividad.getNombreActividad());
        psAct.setString(2, actividad.getDescripcion());
        
        // Validación Fecha Creación
        psAct.setString(3, actividad.getFechaCreacion());
        
        // Validación Fecha Programada
        psAct.setString(4, actividad.getFechaProgramada());

        // CORRECCIÓN: Validación Fecha Inicio (Evita el error de 'None')
        if (actividad.getFechaInicio() == null || actividad.getFechaInicio().equals("None")) {
            psAct.setNull(5, java.sql.Types.VARCHAR);
        } else {
            psAct.setString(5, actividad.getFechaInicio());
        }

        // CORRECCIÓN: Validación Fecha Finalización (Evita el error de 'None')
        if (actividad.getFechaFinalizacion() == null || actividad.getFechaFinalizacion().equals("None")) {
            psAct.setNull(6, java.sql.Types.VARCHAR);
        } else {
            psAct.setString(6, actividad.getFechaFinalizacion());
        }

        psAct.setString(7, actividad.getEstado());
        psAct.setString(8, actividad.getPrioridad());
        psAct.setInt(9, actividad.getIdCreador());
        psAct.setInt(10, actividad.getIdAsignado());

        if (actividad.getIdAsignado2() > 0) {
            psAct.setInt(11, actividad.getIdAsignado2());
        } else {
            psAct.setNull(11, java.sql.Types.INTEGER);
        }

        psAct.setInt(12, actividad.getIdUbicacion());
        psAct.setInt(13, actividad.getIdCampania());

        int filas = psAct.executeUpdate();

        if (filas > 0) {
            rs = psAct.getGeneratedKeys();
            if (rs.next()) {
                int idGenerado = rs.getInt(1);

                psMat = conn.prepareStatement(INSERT_ACTIVIDAD_MATERIAL);
                psMat.setInt(1, idGenerado);
                psMat.setInt(2, idMaterial);
                psMat.setInt(3, cantidadMaterial);
                psMat.executeUpdate();
            }
        }

        conn.commit();
        return true;
    } catch (ClassNotFoundException | SQLException e) {
        try {
            if (conn != null) {
                conn.rollback();
            }
        } catch (SQLException ex) {
            System.err.println("Error en rollback: " + ex.getMessage());
        }
        JOptionPane.showMessageDialog(null, "Error al registrar actividad: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        return false;
    } finally {
        try {
            if (rs != null) rs.close();
            if (psAct != null) psAct.close();
            if (psMat != null) psMat.close();
            if (conn != null) conexion.closeConnection(conn);
        } catch (SQLException ex) {
            System.err.println("Error al cerrar recursos: " + ex.getMessage());
        }
    }
}

    public boolean confirmarEntregaAlmacen(int idActividad, int idMaterial, int cantidadARestar) {
        Connection conn = null;
        PreparedStatement ps1 = null;
        PreparedStatement ps2 = null;

        try {
            conn = conexion.getConnection();
            conn.setAutoCommit(false);

            String sqlEntrega = "UPDATE actividad_materiales SET ENTREGADO = 1 WHERE ID_ACTIVIDAD = ? AND ID_MATERIAL = ?";
            ps1 = conn.prepareStatement(sqlEntrega);
            ps1.setInt(1, idActividad);
            ps1.setInt(2, idMaterial);
            ps1.executeUpdate();

            String sqlStock = "UPDATE material SET CANTIDAD_DISPONIBLE = CANTIDAD_DISPONIBLE - ? WHERE ID_MATERIAL = ?";
            ps2 = conn.prepareStatement(sqlStock);
            ps2.setInt(1, cantidadARestar);
            ps2.setInt(2, idMaterial);
            ps2.executeUpdate();

            conn.commit();
            return true;
        } catch (ClassNotFoundException | SQLException e) {
            try {
                if (conn != null) {
                    conn.rollback();
                }
            } catch (SQLException ex) {
            }
            JOptionPane.showMessageDialog(null, "Error en validación de almacén: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        } finally {
            try {
                if (ps1 != null) {
                    ps1.close();
                }
                if (ps2 != null) {
                    ps2.close();
                }
                if (conn != null) {
                    conexion.closeConnection(conn);
                }
            } catch (SQLException ex) {
            }
        }
    }

    public ClaseActividad[] leerActividades() {
        ClaseActividad[] aActividades = null;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        cantRegistros = 0;

        try {
            conn = conexion.getConnection();
            ps = conn.prepareStatement(SELECT_COUNT_ACTIVIDADES);
            rs = ps.executeQuery();
            if (rs.next()) {
                cantRegistros = rs.getInt("CANT");
            }

            aActividades = new ClaseActividad[cantRegistros];
            ps = conn.prepareStatement(SELECT_ALL_ACTIVIDADES);
            rs = ps.executeQuery();

            int i = 0;
            while (rs.next()) {
                ClaseActividad act = new ClaseActividad();
                act.setIdActividad(rs.getInt("ID_ACTIVIDAD"));
                act.setNombreActividad(rs.getString("NOMBRE_ACTIVIDAD"));
                act.setDescripcion(rs.getString("DESCRIPCION"));
                act.setFechaCreacion(rs.getString("FECHA_CREACION"));
                act.setFechaProgramada(rs.getString("FECHA_PROGRAMADA"));
                act.setFechaInicio(rs.getString("FECHA_INICIO"));
                act.setFechaFinalizacion(rs.getString("FECHA_FINALIZACION"));
                act.setEstado(rs.getString("ESTADO"));
                act.setPrioridad(rs.getString("PRIORIDAD"));
                act.setIdCreador(rs.getInt("ID_CREADOR"));
                act.setIdAsignado(rs.getInt("ID_ASIGNADO"));
                act.setIdAsignado2(rs.getInt("ID_ASIGNADO_2"));
                act.setIdUbicacion(rs.getInt("ID_UBICACION"));
                act.setIdCampania(rs.getInt("ID_CAMPANIA"));
                aActividades[i] = act;
                i++;
            }
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al leer actividades: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conexion.closeConnection(conn);
                }
            } catch (SQLException ex) {
            }
        }
        return aActividades;
    }

    public boolean actualizarActividad(ClaseActividad actividad) {
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = conexion.getConnection();
            ps = conn.prepareStatement(UPDATE_ACTIVIDAD);
            ps.setString(1, actividad.getNombreActividad());
            ps.setString(2, actividad.getDescripcion());
            ps.setString(3, actividad.getFechaProgramada());
            ps.setString(4, actividad.getFechaInicio());
            ps.setString(5, actividad.getFechaFinalizacion());
            ps.setString(6, actividad.getEstado());
            ps.setString(7, actividad.getPrioridad());
            ps.setInt(8, actividad.getIdAsignado());
            ps.setInt(9, actividad.getIdAsignado2());
            ps.setInt(10, actividad.getIdUbicacion());
            ps.setInt(11, actividad.getIdCampania());
            ps.setInt(12, actividad.getIdActividad());

            return ps.executeUpdate() > 0;
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al actualizar: " + e.getMessage());
            return false;
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conexion.closeConnection(conn);
                }
            } catch (SQLException e) {
            }
        }
    }

    public boolean eliminarActividad(int idActividad) {
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = conexion.getConnection();
            ps = conn.prepareStatement(DELETE_ACTIVIDAD);
            ps.setInt(1, idActividad);
            return ps.executeUpdate() > 0;
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar: " + e.getMessage());
            return false;
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conexion.closeConnection(conn);
                }
            } catch (SQLException ex) {
            }
        }
    }

    public ClaseActividad buscarActividad(int idActividad) {
        ClaseActividad act = null;
        try (Connection conn = conexion.getConnection(); PreparedStatement ps = conn.prepareStatement(SELECT_ACTIVIDAD_BY_ID)) {
            ps.setInt(1, idActividad);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    act = new ClaseActividad();
                    act.setIdActividad(rs.getInt("ID_ACTIVIDAD"));
                    act.setNombreActividad(rs.getString("NOMBRE_ACTIVIDAD"));
                    act.setDescripcion(rs.getString("DESCRIPCION"));
                    act.setFechaCreacion(rs.getString("FECHA_CREACION"));
                    act.setFechaProgramada(rs.getString("FECHA_PROGRAMADA"));
                    act.setFechaInicio(rs.getString("FECHA_INICIO"));
                    act.setFechaFinalizacion(rs.getString("FECHA_FINALIZACION"));
                    act.setEstado(rs.getString("ESTADO"));
                    act.setPrioridad(rs.getString("PRIORIDAD"));
                    act.setIdCreador(rs.getInt("ID_CREADOR"));
                    act.setIdAsignado(rs.getInt("ID_ASIGNADO"));
                    act.setIdAsignado2(rs.getInt("ID_ASIGNADO_2"));
                    act.setIdUbicacion(rs.getInt("ID_UBICACION"));
                    act.setIdCampania(rs.getInt("ID_CAMPANIA"));
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al buscar: " + e.getMessage());
        }
        return act;
    }
}
