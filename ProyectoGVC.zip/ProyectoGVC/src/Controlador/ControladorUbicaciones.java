/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import javax.swing.JOptionPane;
import Modelo.ClaseUbicaciones;
import Modelo.ConexionBD;

/**
 *
 * @author porqu
 */
public class ControladorUbicaciones {

  private ConexionBD conexion = new ConexionBD();
    private int cantRegistros;

    public ControladorUbicaciones() {
        conexion = new ConexionBD();
        this.cantRegistros = 0;
    }

    private static final String INSERT_UBICACION
            = "INSERT INTO ubicaciones(RUTA, RC, CODIGO, CALLE_1, CALLE_2, SENTIDO, ESTADO, FECHA_INSTALACION, TIPO_UBICACION, LATITUD, LONGITUD) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String SELECT_ALL_UBICACIONES
            = "SELECT * FROM ubicaciones";

    private static final String UPDATE_UBICACION
            = "UPDATE ubicaciones SET RUTA=?, RC=?, CODIGO=?, CALLE_1=?, CALLE_2=?, SENTIDO=?, ESTADO=?, TIPO_UBICACION=?, LATITUD=?, LONGITUD=? WHERE ID_UBICACION=?";

    public boolean registrarUbicacion(ClaseUbicaciones u) {
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = conexion.getConnection();
            ps = conn.prepareStatement(INSERT_UBICACION);

            ps.setInt(1, u.getRuta());
            ps.setString(2, u.getRc());
            ps.setString(3, u.getCodigo());
            ps.setString(4, u.getCalle1());
            ps.setString(5, u.getCalle2());
            ps.setString(6, u.getSentido());
            ps.setString(7, u.getEstado());
            ps.setString(8, u.getFechaInstalacion());
            ps.setString(9, u.getTipoUbicacion());

            if (u.getTipoUbicacion().equals("ESTACION")) {
                ps.setDouble(10, u.getLatitud());
                ps.setDouble(11, u.getLongitud());
            } else {
                ps.setNull(10, Types.DECIMAL);
                ps.setNull(11, Types.DECIMAL);
            }

            return ps.executeUpdate() > 0;
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al registrar: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conexion.closeConnection(conn);
                }
            } catch (SQLException ex) {
            }
        }
    }

    public ClaseUbicaciones[] leerUbicaciones() {
        ClaseUbicaciones[] aUbicaciones = null;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = conexion.getConnection();
            ps = conn.prepareStatement("SELECT COUNT(*) AS CANT FROM ubicaciones");
            rs = ps.executeQuery();
            if (rs.next()) {
                cantRegistros = rs.getInt("CANT");
            }

            aUbicaciones = new ClaseUbicaciones[cantRegistros];
            ps = conn.prepareStatement(SELECT_ALL_UBICACIONES);
            rs = ps.executeQuery();
            int i = 0;
            while (rs.next()) {
                ClaseUbicaciones u = new ClaseUbicaciones();
                u.setIdUbicacion(rs.getInt("ID_UBICACION"));
                u.setRuta(rs.getInt("RUTA"));
                u.setRc(rs.getString("RC"));
                u.setCodigo(rs.getString("CODIGO"));
                u.setCalle1(rs.getString("CALLE_1"));
                u.setCalle2(rs.getString("CALLE_2"));
                u.setSentido(rs.getString("SENTIDO"));
                u.setEstado(rs.getString("ESTADO"));
                u.setFechaInstalacion(rs.getString("FECHA_INSTALACION"));
                u.setTipoUbicacion(rs.getString("TIPO_UBICACION"));

                Object latObj = rs.getObject("LATITUD");
                if (latObj != null) {
                    u.setLatitud(Double.parseDouble(latObj.toString()));
                } else {
                    u.setLatitud(0.0);
                }

                Object lonObj = rs.getObject("LONGITUD");
                if (lonObj != null) {
                    u.setLongitud(Double.parseDouble(lonObj.toString()));
                } else {
                    u.setLongitud(0.0);
                }

                aUbicaciones[i] = u;
                i++;
            }
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al leer: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conexion.closeConnection(conn);
                }
            } catch (SQLException ex) {
            }
        }
        return aUbicaciones;
    }

    public boolean eliminarUbicacion(int id) {
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = conexion.getConnection();
            ps = conn.prepareStatement("DELETE FROM ubicaciones WHERE ID_UBICACION=?");
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (ClassNotFoundException | SQLException e) {
            return false;
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conexion.closeConnection(conn);
                }
            } catch (SQLException ex) {
            }
        }
    }
}
