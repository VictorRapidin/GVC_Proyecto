
package gvcproyecto.Modelo;


public class ImagenFondo {
    private Image imagen;
    private ImageIcon imageIcono;
    
            
    
}
